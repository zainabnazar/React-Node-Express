const serverless = require('serverless-http');
const express = require('express');
const app = express();
const book = require("./server/index");
// app.get('/', function (req, res) {
//     res.send('You successfully called your first Lambda function!')
// })
app.get('/api', book, (req, res) => {
    console.log("Success!!!!")
})

app.get('/getData', book, (req, res) => {
    console.log("Success!!!!", res.data);
})

app.get('/book', book, (req, res) => {
    console.log("File data:", data);
})
module.exports.handler = serverless(app);