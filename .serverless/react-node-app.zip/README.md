# React-Node-Express

A full-stack projects with React in frontend and Node.js (Express) in the backend

1- Used Node and Express server to create an API.

2- Created React frontend.

3- Made HTTP Requests from React to Node.

4- Test witten to test the api with using Mocha framework.

The App deployed to AWS Lambda using serverless >> https://rld2ng2qv9.execute-api.eu-west-2.amazonaws.com/dev/getData

The App deployed to Heroku

# GitHub actions

Github actions has been added to run the test
